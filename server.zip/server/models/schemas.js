const mongoose = require("mongoose");
//Name, Email, Address, Hobbies(checkbox), Highest Education(radio)

const memberSchema = new mongoose.Schema({
    Name: {type: String, required: true},
    Email: {type: String, required: true},
    Address: {type: String},
    Hobbies: [{type: String}],
    Education: {type: String, required: false}
});

const MemberModel = mongoose.model("Member", memberSchema);

module.exports= MemberModel ;