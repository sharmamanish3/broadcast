const mongoose = require("mongoose");
//const { MemberModel } = require("./schemas");

const memberSchema = new mongoose.Schema({
    Name: {type: String, required: true},
    Email: {type: String, required: true},
    Address: {type: String},
    Hobbies: [{type: String}],
    Education: {type: String, required: false}
});

const MemberModel = mongoose.model("Member", memberSchema);

const createMember = async (memberRecord) =>{
    try {
        console.log("DB Member record ", memberRecord);
        const member = new MemberModel(memberRecord);
        const result = await member.save();
        console.log("Result", result);
        return result;
    } catch(ex) {
        console.log("Error ", ex);
        throw ex;
    }
}

const readMembers = async () =>{
    try {
        console.log("All Members");
        const result = await MemberModel.find().sort("Name");
        console.log("Member results ", result);
        return result;
    } catch(ex) {
        console.log("Error Reading Members Detail ", ex);
        throw ex;
    }
}

const updateMember = async (memberId, updateRecord) => {
    try {
        console.log("Update Member");
        const result = await MemberModel.findByIdAndUpdate(memberId, {
            $set: {
                Name: updateRecord.Name,
                Email: updateRecord.Email,
                Address: updateRecord.Address,
                Hobbies: updateRecord.Hobbies,
                Education: updateRecord.Education,
            }
        }, {new: true});
        console.log("Member results ", result);
        return result;
    } catch(ex) {
        console.log("Error Update Member Record", ex);
        throw ex;
    }
}

const deleteMember = async (memberId) => {
    try {
        console.log("Update Member");
        const result = await MemberModel.findByIdAndRemove(memberId);
        console.log("Delete Result ", result);
        return result;
    } catch(ex) {
        console.log("Error Deleting Member Record", ex);
        throw ex;
    }
}

module.exports = {create: createMember, read: readMembers, update: updateMember, delete: deleteMember}
