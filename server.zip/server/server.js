const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const helmet = require("helmet");
const memberRoute = require("./routes/memberRoute");
const app = express();

mongoose.connect("mongodb://localhost:27017/members", ()=>{
   console.log("Connected successully to MongoDB");
   startApp(); 
});

function startApp(){
    app.use(cors());
    app.use(helmet());
    app.use(express.json());
    app.use("/member", memberRoute);

    app.listen(8001, ()=>{
        console.log("Application listening on port : 8001");
    });
}