const express = require("express");
const member = require("../models/Member");
const router = express.Router();

router.post("/", async (req, res)=>{
    try{
            
        const data = { Name, Email, Address, Hobbies, Highest} = req.body;
        console.log("Data record", data);
        const result = await member.create(data);
        console.log("result", result);
        return res.status(200).send(result);
    } catch(ex) {
        console.log("Error Saving New Member ", ex);
        return res.status(400).send(ex);
    }
});

router.get("/", async (req, res)=>{
        try{
            const result = await member.read();
            console.log("result", result);
            return res.status(200).send(result);
        } catch(ex) {
            console.log("Error Fetching Member Data", ex)
            return res.status(400).send(ex);
        }
    });

router.put("/:id", async (req, res)=>{
        try{
            const data = { Name, Email, Address, Hobbies, Highest} = req.body;
            const recordId = req.params.id;
            const result = await member.update(recordId, data);
            console.log("result", result);
            return res.status(200).send(result);
        } catch(ex) {
            console.log("Error Updating Member Record", ex);
            return res.status(400).send(ex);
        }
    });

router.delete("/:id", async (req, res)=>{
        try{
            const recordId = req.params.id;
            const result = await member.delete(recordId);
            console.log("Deletion result", result);
            return res.status(200).send(result);
        } catch(ex) {
            console.log("Error Deleting Member Record", ex);
            return res.status(400).send(ex);
        }
});

module.exports = router;