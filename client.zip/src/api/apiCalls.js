import axios from 'axios';

const baseUrl = "http://localhost:8001"; //process.env.REACT_APP_API_URL;
const memberUrl = baseUrl+'/member';

export const loadMembers = async ()=>{
    console.log(baseUrl);
    return await axios.get(memberUrl);
};

export const createMember = async (dataRecord)=>{
    return await axios.post(memberUrl, dataRecord);
};

export const deleteMember = async (memberId)=>{
    const deleteUrl = memberUrl+"/"+memberId;
    return await axios.delete(deleteUrl);
};

export const updateMember = async (memberId, dataRecord)=>{
    const updateUrl= memberUrl+"/"+memberId;
    return await axios.put(updateUrl, dataRecord);
};