import React, { useEffect, useState } from 'react';
import { loadMembers } from '../api/apiCalls';

export const MemberList = ()=>{
    
    const [memberGrid, setMemberGrid] = useState([]);

    useEffect(()=>{
        loadMembers().then( ({data}) => { 
            console.log(data);
            setMemberGrid(data);
            }).catch( err => {
                console.log("Failed to fetch data");
                //Show Alert
            });
    },[])

    function PopulateRow({memberRecord}){
        return (
            <div className="row">
                <div className="col-2">
                    {memberRecord.Name}
                </div>
                <div className="col-1">
                {memberRecord.Email}
                </div>
                <div className="col-1">
                    {memberRecord.Address}
                </div>
                <div className="col-3">
                    {memberRecord.Hobbies.concat(" , ")}
                </div>
                <div className="col-3">
                    {memberRecord.Education}
                </div>
                <div className="col-1">
                    <button className="btn btn-primary">Edit</button>
                </div>
                <div className="col-1">
                    <button className="btn btn-danger">Delete</button>
                </div>
            </div>
        )
    }

    return (
        <div className="container-fluid">
            <div className="row">
                <div className="col-2"><h5>Name</h5></div>
                <div className="col-1"><h5>Email</h5></div>
                <div className="col-1"><h5>Address</h5></div>
                <div className="col-3"><h5>Hobbies</h5></div>
                <div className="col-3"><h5>Education</h5></div>
                <div className="col-1"><h5>Edit</h5></div>
                <div className="col-1"><h5>Delete</h5></div>
            </div>
            {memberGrid.map(record => <PopulateRow key={record._id} memberRecord={record}/>)}
        </div>
    )
}