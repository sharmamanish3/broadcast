import React from 'react';

const MemberForm = (MemberRecord, onChangeHandler)=>{

return (
    <div className="container-fluid">
        <div className="row">
            <div className="col-6">Name:</div>
            <div className="col-6"><input type="text" name="Name" value={MemberRecord.Name} onChange={onChangeHandler} /></div>
        </div>
        <div className="row">
            <div className="col-6">Email:</div>
            <div className="col-6"><input type="text" name="Name" value={MemberRecord.Email} onChange={(e)=>onChangeHandler(e)} /></div>
        </div>
        <div className="row">
            <div className="col-6">Address:</div>
            <div className="col-6"><input type="text" name="Name" value={MemberRecord.Address} onChange={(e)=>onChangeHandler(e)} /></div>
        </div>
        <div className="row">
            <div className="col-6">Hobbies:</div>
            <div className="col-6">
                <input type="checkbox" name="Hobbies" value="Chess" onChange={(e)=>onChangeHandler(e)} />
                <input type="checkbox" name="Hobbies" value="Carrom" onChange={(e)=>onChangeHandler(e)} />
                <input type="checkbox" name="Hobbies" value="Reading" onChange={(e)=>onChangeHandler(e)} />
            </div>
        </div>
        <div className="row">
            <div className="col-6">Education:</div>
            <div className="col-6">
                <input type="radio" name="Education" value="BCom" onChange={onChangeHandler} />
                <input type="radio" name="Education" value="PGDCA" onChange={onChangeHandler} />
                <input type="radio" name="Education" value="PHD Science" onChange={onChangeHandler} />
            </div>
        </div>
        <div className="row">
            <div className="col-12">
                <button onClick="">Save</button>
            </div>
        </div>
    </div>
);

}