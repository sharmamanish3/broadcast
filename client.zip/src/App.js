import { MemberList } from './component/MemberList';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';

function App() {
  return (
    <div className="App">
      <MemberList/>
    </div>
  );
}

export default App;
